package com.example.Administration.controller;

import com.example.Administration.model.Flight;
import com.example.Administration.service.FlightService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/administration")
@RestController
public class FlightController {
    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @GetMapping("/getAllFlights")
    public List<Flight> getAllFlights() {
        return flightService.getAllFlights();
    }

    @GetMapping("/get/{flightID}")
    public Flight getFlight(@PathVariable String flightID) {
        return flightService.getFlight(flightID);
    }

    @PostMapping("/createFlight")
    public Flight createFlight(@RequestBody Flight flight) {
        return flightService.create(flight);
    }

    @DeleteMapping("/deleteFlight/{flightId}")
    public String deleteFlight(@PathVariable String flightId) {
        flightService.delete(flightId);
        return "Flight deleted";
    }

    @PutMapping("/updateFlight/{flightId}")
    public Flight updateBook(@RequestBody Flight flight, @PathVariable String flightId) {
        return flightService.update(flight, flightId);
    }

    @DeleteMapping("/deleteAll")
    public String deleteFlights() {
        flightService.deleteAll();
        return "All flights deleted";
    }
}
