package com.example.Administration.service;

import com.example.Administration.model.Flight;
import com.example.Administration.repository.FlightRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightService {

    private final FlightRepository flightRepository;

    public FlightService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    public Flight getFlight(String flightID) {
        return flightRepository.findById(flightID).orElse(null);
    }


    public Flight create(Flight flight) {
        return flightRepository.save(flight);
    }

    public void delete(String flightId) {
        flightRepository.deleteById(flightId);
    }

    public Flight update(Flight flight,String flightId) {
       Flight flight1 = flightRepository.findById(flightId).get();
        flight1.setStatus(flight.getStatus());
        flight1.setLocation(flight.getLocation());
        flight1.setPincode(flight.getPincode());
        flight1.setDeliveryMode(flight.getDeliveryMode());
        flightRepository.save(flight1);
        return flight1;
    }

    public void deleteAll() {
        flightRepository.deleteAll();
    }
}
