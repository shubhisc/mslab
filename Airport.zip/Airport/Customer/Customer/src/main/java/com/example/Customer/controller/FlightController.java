package com.example.Customer.controller;

import com.example.Customer.model.Flight;
import com.example.Customer.service.FlightService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/customer")
@RestController
public class FlightController {
    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @GetMapping("/getAllFlights")
    public List<Flight> getAllFlights() {
        return flightService.getAllFlights();
    }

    @GetMapping("/get/{flightID}")
    public Flight getFlight(@PathVariable String flightID) {
        return flightService.getFlight(flightID);
    }


}
